from pypdf import PdfReader
from rag.retriever import add_documents

def load_document(path):
    reader = PdfReader(path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)

def split_text(text, chunk_size=500):
    words = text.split()
    return [" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)]

def process_pdf(path, source_name):
    text = load_document(path)
    chunks = split_text(text)
    if not chunks:
        return 0
    add_documents(chunks, source_name)
    return len(chunks)
