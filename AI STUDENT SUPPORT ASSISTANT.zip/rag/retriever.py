import os, uuid
import chromadb
from rag.embeddings import create_embeddings

os.makedirs("chroma_db", exist_ok=True)
client = chromadb.PersistentClient(path="chroma_db")
collection = client.get_or_create_collection(name="college_documents", metadata={"hnsw:space": "cosine"})

def add_documents(chunks, source):
    ids = [str(uuid.uuid4()) for _ in chunks]
    embeddings = create_embeddings(chunks)
    collection.add(ids=ids, documents=chunks, embeddings=embeddings,
                   metadatas=[{"source": source} for _ in chunks])

def retrieve_information(question, n_results=4):
    count = collection.count()
    if count == 0:
        return []
    n = min(n_results, count)
    q_embedding = create_embeddings(question)[0]
    result = collection.query(query_embeddings=[q_embedding], n_results=n,
                              include=["documents", "metadatas", "distances"])
    return [
        {"document": doc, "metadata": meta, "distance": dist}
        for doc, meta, dist in zip(result["documents"][0], result["metadatas"][0], result["distances"][0])
    ]
