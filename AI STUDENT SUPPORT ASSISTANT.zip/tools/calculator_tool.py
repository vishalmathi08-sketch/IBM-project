def calculate_percentage(obtained, total):
    if float(total) == 0:
        raise ValueError("Total marks cannot be zero")
    return round((float(obtained) / float(total)) * 100, 2)
