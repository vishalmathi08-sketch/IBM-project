from datetime import datetime

def get_current_date():
    return datetime.now().strftime("%d %B %Y")

def get_college_help():
    return "Academic Office, Examination Cell, Department Office, Student Counselling, Library, IT Support"

def calculate_percentage(obtained, total):
    if total == 0:
        return 0
    return round((float(obtained) / float(total)) * 100, 2)
