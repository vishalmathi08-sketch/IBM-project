from rag.retriever import retrieve_information
from database import get_previous_conversations, save_conversation
from tools.college_tools import get_current_date, get_college_help
from ai_service import generate_answer

def answer_question(question):
    retrieved = retrieve_information(question, 4)
    memory = get_previous_conversations(5)

    context = "\n\n".join(
        f"[Source: {x['metadata'].get('source', 'Unknown')}]\n{x['document']}"
        for x in retrieved
    ) or "No relevant document information found."

    history = "\n".join(f"Student: {q}\nAssistant: {a}" for q, a in memory) or "No previous conversation."

    prompt = f"""You are an AI Student Support Assistant.
Answer clearly and simply for college students.

IMPORTANT RULES:
1. Use the uploaded document context as the primary source.
2. Do not invent college rules, marks, attendance percentages, dates, or policies.
3. If the answer is not present in the context, clearly say that the information was not found in uploaded documents.
4. Use previous conversation only for continuity, not as evidence for new rules.

CURRENT DATE: {get_current_date()}
AVAILABLE SUPPORT SERVICES: {get_college_help()}

DOCUMENT CONTEXT:
{context}

PREVIOUS CONVERSATION:
{history}

STUDENT QUESTION: {question}

ANSWER:"""

    answer = generate_answer(prompt)
    save_conversation(question, answer)
    sources = list(dict.fromkeys(x["metadata"].get("source", "Unknown") for x in retrieved))
    return answer, sources
